// java-only: 批量预编译工具（luac.c 的等价物，供构建期把 .lua 编成 .luac）。
//
// 用途：Android/JVM 打包前把资源目录下的 .lua 全部预编译，运行期 BaseLib.loadFile
//   在 -Dluajvm.luac=true 下优先加载同名 .luac，跳过 Lexer/Parser/CodeGen。
//
// 与 luac.c 的差异：C 的 luac 把多个输入合成单个 chunk（-o 一个输出）；此处是
//   一对一映射（x.lua -> x.luac），因为 require 需要按模块名分别定位文件。
package org.luajvm.tools;

import org.luajvm.compiler.Parser;
import org.luajvm.core.Prototype;
import org.luajvm.vm.LuaChunk;

import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public final class LuacCompiler {
    private LuacCompiler() {
    }

    public static void main(String[] args) throws Exception {
        if (args.length < 1) {
            System.err.println("用法: LuacCompiler <目录或文件> [--strip] [--keep-going]");
            System.err.println("  为每个 x.lua 生成同目录 x.luac。");
            System.err.println("  --strip 去调试信息：体积 0.64x、加载再快约 1.2x，但[破坏 traceback 保真]");
            System.err.println("           -  -  实测运行期错误从 `mod_a.lua:8: ... (local 't')`");
            System.err.println("          退化成 `mod_a.lua:0: ...`（行号丢失、变量名丢失）。");
            System.err.println("          故生产打包[不建议]用 --strip；不 strip 已有约 94% 的加载收益。");
            System.exit(2);
        }
        boolean strip = false, keepGoing = false;
        Path root = null;
        for (String a : args) {
            if ("--strip".equals(a)) strip = true;
            else if ("--keep-going".equals(a)) keepGoing = true;
            else if (root == null) root = Paths.get(a);
        }
        if (root == null || !Files.exists(root)) {
            System.err.println("路径不存在: " + root);
            System.exit(2);
        }

        List<Path> files = new ArrayList<>();
        if (Files.isDirectory(root)) {
            try (var s = Files.walk(root)) {
                s.filter(p -> p.toString().endsWith(".lua")).sorted().forEach(files::add);
            }
        } else {
            files.add(root);
        }

        int ok = 0, failed = 0;
        long srcTotal = 0, outTotal = 0;
        for (Path f : files) {
            byte[] src = Files.readAllBytes(f);
            try {
                // chunkname 必须带 '@' 前缀：luaO_chunkid 靠首字符分类（'@'=文件名、
                //   '='=字面量、无前缀=[string "..."]），裸名会使 traceback 显示成
                //   [string "mod_a.lua"]。undump 直接用 dump 内 source，存什么即最终值。
                Prototype p = Parser.parse(new InputStreamReader(
                        new ByteArrayInputStream(src), StandardCharsets.ISO_8859_1),
                        "@" + f.getFileName());
                byte[] out = LuaChunk.dump(p, strip);
                // 自检：产物必须能 undump 回来，否则宁可不写（避免运行期静默回落掩盖问题）
                LuaChunk.undump(out);
                String name = f.toString();
                Path dst = Paths.get(name.substring(0, name.length() - 4) + ".luac");
                Files.write(dst, out);
                srcTotal += src.length;
                outTotal += out.length;
                ok++;
            } catch (Throwable t) {
                failed++;
                System.err.println("编译失败 " + f + ": " + t);
                if (!keepGoing) {
                    System.err.println("（加 --keep-going 可跳过失败项继续）");
                    System.exit(1);
                }
            }
        }
        System.out.printf("预编译完成: %d 成功, %d 失败%s%n", ok, failed, strip ? "（strip）" : "");
        if (ok > 0) {
            System.out.printf("源码 %.1f KB -> 字节码 %.1f KB (%.2fx)%n",
                    srcTotal / 1024.0, outTotal / 1024.0, (double) outTotal / srcTotal);
        }
        if (failed > 0 && !keepGoing) System.exit(1);
    }
}
